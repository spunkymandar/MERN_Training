const sayHi = require('./4.js')
sayHi.sayHi('susan')
sayHi.sayBye('someone')

