const profile = {
    firstName: "Mandar", 
    lastName: "Jog", 
    email: "mandarmjog@gmail.com"
  };
  
  const { firstName: firstName, lastName: lastName, email: email } = profile;
  console.log(firstName); 
  console.log(lastName); 
  console.log(email); 
